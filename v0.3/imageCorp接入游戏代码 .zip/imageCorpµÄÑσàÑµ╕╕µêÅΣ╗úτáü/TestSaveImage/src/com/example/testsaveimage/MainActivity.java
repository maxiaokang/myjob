package com.example.testsaveimage;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.playcrab.shotpic.SavePicListener;
import com.playcrab.shotpic.SavePictures;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    private ImageView resultView;
    private Button button;
    /** 首先默认个文件保存路径 */

    SavePictures savePictures;
    private String SAVE_REAL_PATH = Environment.getExternalStorageDirectory() + "/xiaokang/test/";
    private String imageNameString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultView = (ImageView) findViewById(R.id.result_image);
        button = (Button) findViewById(R.id.btn);

        /*
         * 1、调用getInstance初始化截图工具类
         * 2、调用initData传递自定义的上下文类,实现SavePicListener接口，获取截图后的状态：status
         * 返回图片截取状态（0成功，－1失败）；describe返回截图结果描述；
         * 3、调用corpImage(),传入文件保存路径及图片名，实现自定义截图及图片保存
         */
        savePictures = SavePictures.getInstance();

        savePictures.initData(this, new SavePicListener() {

            @Override
            public void status(int status, String describe) {
                // TODO Auto-generated method stub
                if (status == 0) {
                    Toast.makeText(MainActivity.this, describe, Toast.LENGTH_LONG).show();
                    File file = new File(SAVE_REAL_PATH + imageNameString);
                    if (file.exists()) {
                        Bitmap bm = BitmapFactory.decodeFile(SAVE_REAL_PATH + imageNameString);
                        // 将图片显示到ImageView中
                        resultView.setImageBitmap(bm);
                    }
                } else if (status == -1) {// 保存失败
                    Toast.makeText(MainActivity.this, describe, Toast.LENGTH_LONG).show();
                }
            }
        });
        /*
         * 裁剪图片
         */
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                showEdit();

            }
        });
    }

    protected void showEdit() {
        AlertDialog.Builder aBuilder = new AlertDialog.Builder(MainActivity.this);
        LinearLayout layout = new LinearLayout(MainActivity.this);
        layout.setOrientation(1);
        final EditText path = new EditText(MainActivity.this);
        final EditText name = new EditText(MainActivity.this);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.CHINA);
        imageNameString = sdf.format(new Date());
        path.setText(SAVE_REAL_PATH);
        name.setText(imageNameString);
        layout.addView(path);
        layout.addView(name);
        aBuilder.setView(layout);
        
        aBuilder.setPositiveButton("开始截图", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                SAVE_REAL_PATH = path.getText().toString();
                imageNameString = name.getText().toString();
                savePictures.corpImage(SAVE_REAL_PATH, imageNameString);

            }
        }).create().show();

    }

    /*
     * onActivityResult方法重写
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent result) {
        savePictures.onActivityResult(requestCode, resultCode, result);

    }

}
