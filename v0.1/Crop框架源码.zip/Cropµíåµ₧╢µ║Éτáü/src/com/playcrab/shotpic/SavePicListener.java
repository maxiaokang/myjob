package com.playcrab.shotpic;


public interface SavePicListener {
    void status(int status, String describe);
}
