package com.example.testsaveimage;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.playcrab.shotpic.SavePicListener;
import com.playcrab.shotpic.SavePictures;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;

import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
    private ImageView resultView;
    private Button button;
    /** 首先默认个文件保存路径 */

    SavePictures savePictures;
    private final String SAVE_REAL_PATH = Environment.getExternalStorageDirectory() + "/xiaokang/test/";
    String imageNameString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultView = (ImageView) findViewById(R.id.result_image);
        button = (Button) findViewById(R.id.btn);
        /*
         * 1、调用getInstance初始化截图工具类
         * 2、调用initData传递自定义的上下文类,实现SavePicListener接口，获取截图后的状态：status
         * 返回图片截取状态（0成功，－1失败）；describe返回截图结果描述；
         * 3、调用corpImage(),传入文件保存路径及图片名，实现自定义截图及图片保存
         */
        savePictures = SavePictures.getInstance();
       
        savePictures.initData(this, new SavePicListener() {

            @Override
            public void status(int status, String describe) {
                // TODO Auto-generated method stub
                if (status == 0) {
                    Toast.makeText(MainActivity.this, describe, Toast.LENGTH_LONG).show();
                    File file = new File(SAVE_REAL_PATH + imageNameString);
                    if (file.exists()) {
                        Bitmap bm = BitmapFactory.decodeFile(SAVE_REAL_PATH + imageNameString);
                        // 将图片显示到ImageView中
                        resultView.setImageBitmap(bm);
                    }
                } else if (status == -1) {// 保存失败
                    Toast.makeText(MainActivity.this, describe, Toast.LENGTH_LONG).show();
                }
            }
        });
        /*
         * 裁剪图片
         */
        button.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss",Locale.CHINA);
                imageNameString = sdf.format(new Date());
                savePictures.corpImage(SAVE_REAL_PATH, imageNameString);
            }
        });
    }

    /*
     * onActivityResult方法重写
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent result) {
        savePictures.onActivityResult(requestCode, resultCode, result);

    }

}
